@echo off

if errorlevel 255 goto exit
if errorlevel 96 goto tandy
if errorlevel 80 goto vgalemm
:egalemm
if errorlevel 59 goto egalemmAm
if errorlevel 57 goto egalemmPS2
if errorlevel 55 goto egalemmHigh
pause
vgalemm2 -e -x %1 %2 %3
goto exit

:egalemmAm
vgalemm2 -e -d %1 %2 %3
goto exit

:egalemmPS2
vgalemm2 -e -p %1 %2 %3
goto exit

:egalemmHigh
vgalemm2 -e -o %1 %2 %3
goto exit

:tandy
tgalemmi %1 %2 %3
goto exit

:vgalemm
if errorlevel 91 goto vgalemmAm
if errorlevel 89 goto vgalemmPS2
if errorlevel 87 goto vgalemmHigh
vgalemm2 -v -x %1 %2 %3
goto exit

:vgalemmAm
vgalemm2 -v -d %1 %2 %3
goto exit

:vgalemmPS2
vgalemm2 -v -p %1 %2 %3
goto exit

:vgalemmHigh
vgalemm2 -v -o %1 %2 %3
:exit
